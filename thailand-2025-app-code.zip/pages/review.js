export default function Review() {
  return (
    <main style={{fontFamily:'system-ui, sans-serif', padding:'24px'}}>
      <h1>Review</h1>
      <p>כאן נציג את "הסוכן הבודק" (Verifier) ונחזיר פסק‑דין על המלצות.</p>
    </main>
  );
}
