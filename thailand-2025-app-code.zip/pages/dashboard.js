export default function Dashboard() {
  return (
    <main style={{fontFamily:'system-ui, sans-serif', padding:'24px'}}>
      <h1>Dashboard</h1>
      <p>כאן נציג את המיקרו/מאקרו, יחס 60/25/15, ועוגנים (טיסות, Halfmoon, מפגשי ערב).</p>
    </main>
  );
}
