export default function Suggest() {
  return (
    <main style={{fontFamily:'system-ui, sans-serif', padding:'24px'}}>
      <h1>Suggest</h1>
      <p>טופס "פורמט הצעת פעילות" יופיע כאן. בשלב הבא נחבר ל‑Supabase.</p>
    </main>
  );
}
